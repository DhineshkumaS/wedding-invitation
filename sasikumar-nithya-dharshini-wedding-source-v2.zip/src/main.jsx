import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  CalendarDays, Clock3, MapPin, Heart, ArrowDown, ExternalLink,
  CalendarPlus, Navigation, Flower2
} from "lucide-react";
import "./style.css";

const wedding = {
  groom: "S. Sasikumar",
  groomQualification: "B.Com. (C.A.)",
  bride: "N. Nithya Dharshini",
  brideQualification: "B.B.A.",
  dateLabel: "Monday, 16 November 2026",
  // Local time in India (UTC+05:30)
  start: new Date("2026-11-16T04:30:00+05:30"),
  end: new Date("2026-11-16T06:00:00+05:30"),
  timeLabel: "4:30 AM – 6:00 AM",
  venue: "Renuka Mahal",
  address: "Valparai Main Road, Rangasamuthram",
};

const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  `${wedding.venue}, ${wedding.address}`
)}`;

function Countdown() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const remaining = wedding.start.getTime() - now.getTime();
  if (remaining <= 0) {
    return (
      <div className="countdown-ended">
        <Heart size={17} fill="currentColor" />
        <span>With love, we celebrated our special day</span>
      </div>
    );
  }
  const days = Math.floor(remaining / 86400000);
  const hours = Math.floor((remaining % 86400000) / 3600000);
  const minutes = Math.floor((remaining % 3600000) / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  return (
    <div className="countdown" aria-label="Time until the wedding">
      {[
        ["Days", days],
        ["Hours", hours],
        ["Minutes", minutes],
        ["Seconds", seconds],
      ].map(([label, value]) => (
        <div className="countdown-unit" key={label}>
          <strong>{String(value).padStart(2, "0")}</strong>
          <span>{label}</span>
        </div>
      ))}
    </div>
  );
}

function addToCalendar() {
  const format = (date) =>
    date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Wedding Invitation//EN",
    "CALSCALE:GREGORIAN",
    "BEGIN:VEVENT",
    `UID:sasikumar-nithya-dharshini-${wedding.start.getTime()}@wedding-invitation`,
    `DTSTAMP:${format(new Date())}`,
    `DTSTART:${format(wedding.start)}`,
    `DTEND:${format(wedding.end)}`,
    "SUMMARY:Wedding of S. Sasikumar & N. Nithya Dharshini",
    `LOCATION:${wedding.venue}, ${wedding.address}`,
    "DESCRIPTION:Your presence and blessings will make our special day memorable.",
    "END:VEVENT",
    "END:VCALENDAR",
  ].join("\r\n");
  const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "gururajan-shagathiya-wedding.ics";
  a.click();
  URL.revokeObjectURL(url);
}

function FloralMark() {
  return (
    <div className="floral-mark" aria-hidden="true">
      <span className="petal p1" /><span className="petal p2" />
      <span className="petal p3" /><span className="petal p4" />
      <span className="petal p5" /><span className="petal p6" />
      <span className="mark-center">ॐ</span>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [invitationOpened, setInvitationOpened] = useState(false);
  const navItems = useMemo(() => [
    ["Our Invitation", "#invitation"],
    ["The Details", "#details"],
    ["Venue", "#venue"],
  ], []);

  return (
    <main>
      <div className="topline"><span /> SRI MURUGAN THUNAI <span /></div>
      <header className="site-header">
        <a className="brand" href="#home" aria-label="Wedding home">G <span>&</span> S</a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          {menuOpen ? "Close" : "Menu"}
        </button>
        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {navItems.map(([label, href]) => (
            <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}</a>
          ))}
        </nav>
      </header>

      <section className="hero" id="home">
        <div className="hero-glow" />
        <div className="hero-content">
          <p className="eyebrow"><span className="tiny-diamond">✦</span> WITH THE BLESSINGS OF OUR FAMILIES <span className="tiny-diamond">✦</span></p>
          <FloralMark />
          <p className="script-kicker">Together with our families</p>
          <h1><span>{wedding.groom}</span><em>and</em><span>{wedding.bride}</span></h1>
          <div className="gold-rule"><span>✦</span></div>
          <p className="hero-date">16 <span>·</span> NOVEMBER <span>·</span> 2026</p>
          <p className="hero-invite">joyfully invite you to share in the beginning<br className="desktop-break" /> of our forever.</p>
          <button type="button" className="scroll-cue" onClick={() => {
            setInvitationOpened(true);
            window.setTimeout(() => document.getElementById("invitation")?.scrollIntoView({ behavior: "smooth" }), 80);
          }}>Open Invitation <ArrowDown size={15} /></button>
        </div>
        <div className="corner corner-tl" /><div className="corner corner-tr" />
        <div className="corner corner-bl" /><div className="corner corner-br" />
      </section>

      {invitationOpened && <>
      <section className="invitation section-light" id="invitation">
        <div className="section-ornament">❧ <span>✦</span> ❧</div>
        <p className="eyebrow dark-eyebrow">A NOTE FROM THE HEART</p>
        <h2>Wedding <i>Invitation</i></h2>
        <p className="invitation-copy">
          With the blessings of our parents and elders, we cordially invite you
          and your family to join us on the joyous occasion of our marriage.
        </p>
        <div className="couple-card">
          <div className="person">
            <span className="person-label">THE GROOM</span>
            <h3>{wedding.groom}</h3>
            <p className="qualification">{wedding.groomQualification}</p>
          </div>
          <div className="ampersand">&</div>
          <div className="person">
            <span className="person-label">THE BRIDE</span>
            <h3>{wedding.bride}</h3>
            <p className="qualification">{wedding.brideQualification}</p>
          </div>
        </div>
        <p className="blessing">Your presence and blessings will make our special day even more memorable.</p>
        <div className="section-ornament bottom-ornament">❧ <span>✦</span> ❧</div>
      </section>

      <section className="details-section" id="details">
        <div className="details-heading">
          <p className="eyebrow">SAVE THE DATE</p>
          <h2>A day to <i>remember</i></h2>
          <p>We would be honoured to celebrate this beautiful beginning with you.</p>
        </div>
        <div className="details-grid">
          <article className="detail-card">
            <div className="detail-icon"><CalendarDays size={23} strokeWidth={1.5} /></div>
            <p className="detail-label">THE DATE</p>
            <h3>16 November 2026</h3>
            <p>Sunday</p>
          </article>
          <article className="detail-card">
            <div className="detail-icon"><Clock3 size={23} strokeWidth={1.5} /></div>
            <p className="detail-label">THE TIME</p>
            <h3>4:30 AM – 6:00 AM</h3>
            <p>Morning ceremony</p>
          </article>
          <article className="detail-card" id="venue">
            <div className="detail-icon"><MapPin size={23} strokeWidth={1.5} /></div>
            <p className="detail-label">THE VENUE</p>
            <h3>Renuka Mahal</h3>
            <p>Valparai Main Road,<br />Rangasamuthram</p>
          </article>
        </div>
        <div className="detail-actions">
          <a className="button button-gold" href={mapUrl} target="_blank" rel="noreferrer">
            <Navigation size={16} /> Get directions <ExternalLink size={14} />
          </a>
          <button className="button button-outline" onClick={addToCalendar}>
            <CalendarPlus size={16} /> Add to calendar
          </button>
        </div>
      </section>

      <section className="countdown-section">
        <div className="countdown-flower" aria-hidden="true">✳</div>
        <p className="eyebrow">UNTIL WE SAY “I DO”</p>
        <h2>Counting down to <i>forever</i></h2>
        <Countdown />
        <div className="gold-rule"><span>♡</span></div>
        <p className="countdown-note">Two hearts, one beautiful journey.</p>
      </section>

      <footer className="footer">
        <div className="footer-flourish">✦ ❧ ✦</div>
        <p className="script-kicker">With love and gratitude</p>
        <h2>{wedding.groom} <span>&</span> {wedding.bride}</h2>
        <p className="footer-message">Your presence is the greatest gift.<br />We look forward to celebrating with you.</p>
        <div className="footer-date">16 · 11 · 2026</div>
        <div className="footer-bottom">MADE WITH <Heart size={12} fill="currentColor" /> FOR OUR SPECIAL DAY</div>
      </footer>
      </>}
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);
